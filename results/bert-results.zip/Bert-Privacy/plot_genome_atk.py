# plot the attack accuracy per nucleotide


import matplotlib
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import seaborn as sns; sns.set()
sns.set_style("whitegrid")
import numpy as np
font = {'size' : 16}
matplotlib.rc('font', **font)


from genome_acc import genome_acc_val, genome_rounding_acc, genome_rounding_util, genome_dp_acc, genome_dp_util, genome_minmax_util, genome_minmax_acc
from genome_acc import medical_util, medical_rounding_MLP, medical_dp_MLP, medical_minmax_MLP, medical_rounding_DANN, medical_dp_DANN, medical_minmax_DANN
from genome_acc import medical_atk_stats, medical_atk_avg, airline_atk_stats, airline_atk_avg, medical_cls_names, airline_cls_names

ARCH_ORDER = ['bert', 'transformer-xl', 'xlnet', 'gpt', 'gpt-2', 'roberta', 'xlm', 'ernie']


settings = {
    "bert": ('#1f77b4',"."),
    "gpt": ('#aec7e8',"v"),
    "gpt-2": ('#ff7f0e',"^"),
    "xlm": ("#ffbb78","<"),
    "xlnet": ("#2ca02c",">"),
    "transformer-xl": ('#9467bd',"+"),
    "roberta": ("#e377c2","x"),
    "ernie": ("#17becf","s"),
    "baseline": ("#000000","*")
}

def newline(ax, p1, p2, **kwargs):
    # xmin, xmax = ax.get_xbound()

    # if(p2[0] == p1[0]):
    #     xmin = xmax = p1[0]
    #     ymin, ymax = ax.get_ybound()
    # else:
    #     ymax = p1[1]+(p2[1]-p1[1])/(p2[0]-p1[0])*(xmax-p1[0])
    #     ymin = p1[1]+(p2[1]-p1[1])/(p2[0]-p1[0])*(xmin-p1[0])
    l = mlines.Line2D([p1[0], p2[0]], [p1[1],p2[1]], **kwargs)
    ax.add_line(l)
    return l


def plot_atk_acc_per_idx():
    fig, axs = plt.subplots(figsize = (8, 6), ncols = 1, nrows =  1)
    # axs.set_title("Inference Accuracy per Nucleotide")
    avg_acc = dict()
    for arch in genome_acc_val:
        atk_acc = np.array(genome_acc_val[arch])
        idx = [i+1 for i in range(atk_acc.shape[0])]
        avg = np.mean(atk_acc)
        axs.plot(idx, atk_acc, color = settings[arch][0], label = arch + " (avg. = {:.3f})".format(avg), marker = settings[arch][1])
        axs.set_xticks(idx)
        axs.set_xticklabels([str(i) for i in idx])
        avg_acc[arch] = np.mean(atk_acc)

        axs.legend()
    axs.set_xlabel("Position")
    axs.set_ylabel("Accuracy")
    print(avg_acc)

    # x = list(range(len(genome_acc_val)))
    # y = [avg_acc[arch] for arch in genome_acc_val]

    # axs.bar(x, y)

    fig.savefig('genome_acc_avg.png', dpi = 108)
    return


def plot_atk_acc_with_defense(axs, results, utility, name = 'default', xlabel = 'param', log = False):
    # fig, axs = plt.subplots(figsize = (8, 10), ncols = 1, nrows =  2)
    axs, axs_trade = axs[0], axs[1]
    params = []
    # selected_pos = [0, 4, 9, 14, 19]
    selected_pos = [i for i in range(20)]
    avgs = dict()
    for result in results:
        param, acc_dict = result
        if(name == 'Min-Max'):
            param = 1.0 / param
        params.append(param)


        for i, arch in enumerate(acc_dict):
            # if(i > 0):
            #     break
            selected_val = [acc_dict[arch][idx] for idx in selected_pos]
            x_pos = np.array([param for _ in selected_val])
            # axs.scatter(x_pos, selected_val, color = settings[arch][0], marker = settings[arch][1])
            # axs.line(x = [param, param], y = [np.min(selected_val), np.max(selected_val)], color = settings[arch][0])
            # newline(axs, [param, np.min(selected_val)], [param, np.max(selected_val)], color = settings[arch][0])
            if(not arch in avgs):
                avgs[arch] = list()
            avgs[arch].append(np.mean(acc_dict[arch]))
    print(avgs)

    
    params = np.array(params)

    arch_util = dict()
    for result in utility:
        _, util = result
        for arch in util:
            if(not arch in arch_util):
                arch_util[arch] = list()
            arch_util[arch].append(util[arch][1])


    for arch in avgs:
        print(params.shape)
        print(avgs[arch])
        avgs[arch]
        axs.plot(params, avgs[arch], color = settings[arch][0], label = arch, marker = settings[arch][1])
        axs.plot(params, [-x for x in arch_util[arch]], color = settings[arch][0], marker = settings[arch][1])

    axs.set_ylim(-1.0, 1.0)
    y_pos = [-1.0, -0.8, -0.6, -0.4, -0.2, 0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
    axs.axhline(y = 0.25, color = '#000000', linestyle = '--', label = 'baseline')
    axs.axhline(y = -0.5, color = '#000000', linestyle = '--')
    axs.set_xticks(np.array(params))
    axs.legend()
    axs.set_title("{} Defense on Genome Task".format(name))
    axs.set_yticks(np.array(y_pos))
    axs.set_yticklabels([str(abs(x)) for x in y_pos])
    axs.set_xlabel(xlabel)
    axs.set_ylabel('Utility                     Attack Accuracy')
    
    if(log):
        axs.set_xscale('log')

    # # plot the util
    # # axs_util = axs.twinx()
    # axs_util.invert_yaxis()
    # axs_util.set_ylim(1.0, 0.0)
    # axs_util.set_xticks(np.array(params))
    # axs_util.set_xticklabels(['' for _ in params])
    # axs_util.set_ylabel('Utility')

    # axs_util.axhline(y = 0.5, color = '#000000', linestyle = '--', label = 'baseline')


    #     axs_util.set_xscale('log')

    

    
    # for arch in arch_util:
    #     axs_util.plot(params, arch_util[arch], color = settings[arch][0], label = arch, marker = settings[arch][1])
    
        
        
    
    # fig.savefig('genome_defense_{}.png'.format(name.lower()), dpi = 108)
    # # then give the curve (x: utility, y: attack)
    # print(avgs)
    # print(arch_util)
    # plt.clf()
    # fig, axs = plt.subplots(figsize = (10, 8), ncols = 1, nrows =  1)
    for arch in arch_util:
        axs_trade.plot(arch_util[arch], avgs[arch], color = settings[arch][0], label = arch, marker = settings[arch][1])
    axs_trade.set_title("Genome {} Trade-off".format(name))
    axs_trade.set_xlabel('Utility')
    axs_trade.set_ylabel("Attack Accuracy")
    axs_trade.legend()
    axs_trade.set_xlim(0.0, 1.0)
    axs_trade.set_ylim(0.0, 1.0)
    
        
    # fig.savefig('genome_{}_tradeoff.png'.format(name), dpi = 108)
    
        
    
    
    
            
def plot_genome_util():
    acc_dict = genome_rounding_util[0][1]
    fig, axs = plt.subplots(figsize = (10, 6), ncols = 1, nrows =  1)
    x = list(range(len(acc_dict)))

    # print(acc_dict)
    y = [acc_dict[arch][0]  for arch in acc_dict]
    labels = [arch for arch in acc_dict]
    axs.bar(x, y)
    axs.set_xlabel('')
    axs.set_xticks(x)
    axs.set_xticklabels(labels)
    axs.set_ylabel("Accuracy")
    axs.axhline(y = 0.5, color = '#000000', linestyle = '--', label = 'baseline')
    fig.savefig('genome_utility.png', dpi = 108)



def plot_medical_util():
    acc_dict = medical_util
    fig, axs = plt.subplots(figsize = (10, 6), ncols = 1, nrows =  1)
    x = list(range(len(acc_dict)))

    # print(acc_dict)
    y = [acc_dict[arch]  for arch in acc_dict]
    labels = [arch for arch in acc_dict]
    axs.bar(x, y)
    axs.set_xlabel('')
    axs.set_xticks(x)
    axs.set_xticklabels(labels)
    axs.set_ylabel("Accuracy")
    axs.axhline(y = 0.1, color = '#000000', linestyle = '--', label = 'baseline')
    fig.savefig('medical_utility.png', dpi = 108)


def plot_medical_acc_with_defense(axs, val, name = 'default', xlabel = '', log = False):
    # fig, axs = plt.subplots(figsize = (8, 10), ncols = 1, nrows =  2)
    axs, axs_trade = axs[0], axs[1]
    pro_avg_atk_acc = dict()
    pro_avg_util_acc = dict()
    plt.subplots_adjust(top=0.95, bottom=0.05, left=0.05, right=0.95)
    for arch in val:
        pro_avg_atk_acc[arch] = list()
        pro_avg_util_acc[arch] = list()
        params = []
        for RESULT in val[arch]:
            param, result_list = RESULT[0]
            atk_acc = np.array([x[1] for x in result_list])
            pro_acc = np.array([x[2] for x in result_list])
            util_acc = np.array([x[3] for x in result_list])
            pro_util_acc = np.array([x[4] for x in result_list])
            if(name == 'Min-Max'):
                param = 1.0 / param
            params.append(param)
            pro_avg_atk_acc[arch].append(np.mean(pro_acc))
            pro_avg_util_acc[arch].append(np.mean(pro_util_acc))
            x_pos = [param for _ in atk_acc]
            axs.scatter(x_pos, pro_acc, color = settings[arch][0], marker = settings[arch][1])

    for arch in pro_avg_atk_acc:
        axs.plot(params, pro_avg_atk_acc[arch], color = settings[arch][0], label = arch, marker = settings[arch][1])
        axs.plot(params, [-x for x in pro_avg_util_acc[arch]], color = settings[arch][0], marker = settings[arch][1])

    y_pos = [-1.0, -0.8, -0.6, -0.4, -0.2, 0.0, 0.2, 0.4, 0.6, 0.8, 1.0]
    axs.set_ylim(-1.0, 1.0)
    axs.axhline(y = 0.5, color = '#000000', linestyle = '--', label = 'baseline')
    axs.axhline(y = -0.1, color = '#000000', linestyle = '--')
    axs.set_xticks(np.array(params))
    axs.set_yticks(np.array(y_pos))
    axs.set_yticklabels([str(abs(x)) for x in y_pos])
    axs.legend()
    axs.set_title("{} Defense on Medical Task".format(name))
    axs.set_xlabel(xlabel)
    axs.set_ylabel('Utility                     Attack Accuracy')
    if(log):
        axs.set_xscale('log')
    #     axs_util.set_xscale('log')
    # for arch in pro_avg_util_acc:
    #     axs_util.plot(params, pro_avg_util_acc[arch], color = settings[arch][0], label = arch, marker = settings[arch][1])

    # axs_util.invert_yaxis()
    # axs_util.set_ylim(1.0, 0.0)
    # axs_util.set_xticks(np.array(params))
    # axs_util.set_xticklabels(['' for _ in params])
    # axs_util.set_ylabel('Utility')
    # axs_util.axhline(y = 0.1, color = '#000000', linestyle = '--', label = 'baseline')


    # fig.savefig("medical_{}_defense.png".format(name), dpi = 108)
    # plt.clf()
    # fig, axs = plt.subplots(figsize = (10, 8), ncols = 1, nrows =  1)
    for arch in pro_avg_util_acc:
        axs_trade.plot(pro_avg_util_acc[arch], pro_avg_atk_acc[arch], color = settings[arch][0], label = arch, marker = settings[arch][1])
    axs_trade.set_title("Medical {} Trade-off".format(name))
    axs_trade.set_xlabel('Utility')
    axs_trade.set_ylabel("Attack Accuracy")
    axs_trade.legend()
    axs_trade.set_xlim(0.0, 1.0)
    axs_trade.set_ylim(0.0, 1.0)
    
        
    # fig.savefig('medical_{}_tradeoff.png'.format(name), dpi = 108)


def plot_defense_suite():
    fig, axs = plt.subplots(figsize = (28, 24), ncols = 3, nrows =  4)
    plot_atk_acc_with_defense([axs[0][0], axs[1][0]], genome_rounding_acc, genome_rounding_util, name = 'Rounding', xlabel = '$r$', log = False)
    plot_atk_acc_with_defense([axs[0][1], axs[1][1]], genome_dp_acc, genome_dp_util, name = 'DP', xlabel = '$\epsilon$', log = True)
    plot_atk_acc_with_defense([axs[0][2], axs[1][2]], genome_minmax_acc, genome_minmax_util, name = 'Min-Max', xlabel = '$\lambda$', log = True)


    plot_medical_acc_with_defense([axs[2][0], axs[3][0]], medical_rounding_DANN, name = 'Rounding', xlabel = '$r$')
    plot_medical_acc_with_defense([axs[2][1], axs[3][1]], medical_dp_DANN, name = 'DP', xlabel = '$\epsilon$', log = True)    
    plot_medical_acc_with_defense([axs[2][2], axs[3][2]], medical_minmax_DANN, name = 'Min-Max', xlabel = '$\lambda$', log = True)
    fig.savefig("medical_total_defense.png", dpi = 108)    


    

def plot_medical_atk(axs, atk_stats, cls_names, title, index, show_ylabel = False):
    # fig, axs  = plt.subplots(figsize = (10, 6), ncols = 1, nrows =  1)
    gap = 0.8 / len(atk_stats)
    idx = np.array(list(range(10)))
    # cls_names = ["leg", "hand", "spine", "chest", "ankle", "head", "hip", "arm", "face", "shoulder"]
    arch_avg = []
    arch_max = []
    

    
    for i, arch in enumerate(ARCH_ORDER):
        data = atk_stats[arch]
        _yerr = [np.sqrt(var) for _, _, _, var in data]
        y_val = [y for _, y, _, _ in data]
        x = idx

        y_val = np.array(y_val)
        arch_avg.append(np.mean(y_val))
        arch_max.append(np.max(y_val))
        _yerr = np.array(_yerr)
        print("{}:{}".format(arch, _yerr.shape))
        axs.bar(x + i * gap, y_val, yerr = _yerr, width = gap, color = settings[arch][0], label = arch)

    axs.set_xticks(np.array(list(range(len(data)))) + 0.4)
    axs.set_xticklabels(cls_names)
    
    axs.axhline(y = 0.5, color = '#000000', linestyle = '--', label = 'baseline')
    axs.set_ylim(0.0, 1.0)
    axs.set_xlabel(index)

    if(show_ylabel):
        axs.set_ylabel("Attack Accuracy")
    axs.legend(loc = 'lower right')
    axs.set_title(title)
    # fig.savefig('medical_atk_result.png', dpi = 108)
    # for i, arch in enumerate(ARCH_ORDER):
    #     print("{}:avg. {} worst {}".format(arch, arch_avg[i], arch_max[i]))


def plot_keyword_atk_avg(axs, atk_avg, title, index):
    labels = ["SVM (w.b.)", "MLP (w.b.)", "SVM (b.b.)", "MLP (b.b.)", "DANN (b.b.)"]
    gap = 0.8 / len(labels)
    idx = np.array(list(range(len(ARCH_ORDER))))
    patterns = ('+', 'x', '*', 'o', '.')
    for i in range(len(labels)):
        dat = []
        clist = []
        for arch in ARCH_ORDER:
            dat.append(atk_avg[arch][i])
            clist.append(settings[arch][0])
        dat = np.array(dat)
        axs.bar(idx + i * gap, dat, width = gap - 0.02, color = clist, label = labels[i], hatch = patterns[i], ecolor='black')
    axs.set_xticks(idx + 0.4)
    axs.set_xticklabels(ARCH_ORDER)
    axs.axhline(y = 0.5, color = '#000000', linestyle = '--', label = 'baseline')
    axs.legend(loc = 'lower right')
    axs.set_ylim(0.0, 1.0)
    axs.set_title(title)
    axs.set_xlabel(index)
    
    
    
    
        
            
        
            
    
        
    
def plot_keyword_atk_suite():
    fig, axs  = plt.subplots(figsize = (18, 18), ncols = 2, nrows =  2)
    plt.subplots_adjust(top=0.95, bottom=0.1, left=0.01, right=0.99)
    plot_medical_atk(axs[0][0], airline_atk_stats, airline_cls_names, 'Airline: DANN', index = '(a)', show_ylabel = True)
    plot_keyword_atk_avg(axs[0][1], airline_atk_avg, "Airline: Average", index = '(b)')
    plot_medical_atk(axs[1][0], medical_atk_stats, medical_cls_names, 'Medical: DANN', index = '(c)')
    plot_keyword_atk_avg(axs[1][1], medical_atk_avg, "Medical: Average", index = '(d)')
    fig.savefig('keyword_atk_result.png', dpi = 108)
    
   
    
        
        
        
    
if __name__ == '__main__':

    # plot_medical_util()
    # plot_atk_acc_per_idx()

    # plot_genome_util()
    # plot_medical_atk()
    plot_keyword_atk_suite()
    
