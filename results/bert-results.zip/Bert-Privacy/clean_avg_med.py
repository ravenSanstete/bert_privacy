import parse

fmt = '({}) INFER {} Best ACC in Valid Dataset. {} Average ACC DescribeResult(nobs=10, minmax=({min}, {max}), mean={mean}, variance={variance}, skewness={}, kurtosis={})'



f = open('avg_airline.txt', 'r')




name_list = ["bert", "gpt", "gpt-2", "xlm", "xlnet", "transformer-xl", "roberta", "ernie"]
medical_atk_stats = {arch: list([0]*10) for arch in name_list}

CITY_ORDER = ['Hong Kong','London','Toronto','Paris','Rome','Sydney','Dubai','Bangkok','Singapore','Frankfurt']

CITY_ORDER = {name: i for i, name in enumerate(CITY_ORDER)}
print(medical_atk_stats)
name = 0

for line in f:
    line = line[:-1]
    # print(line)
    parsed = parse.parse(fmt, line)
    # print(parsed)
    if(not parsed):
        continue
    
    # medical_atk_stats[name_list[name]].append((float(parsed['min']),float(parsed['mean']), float(parsed['max']), float(parsed['variance'])))
    medical_atk_stats[name_list[name]][CITY_ORDER[parsed[1]]] = (float(parsed['min']),float(parsed['mean']), float(parsed['max']), float(parsed['variance']))
    print(name_list[name]+":"+parsed[1])
    
    if(int(parsed[0]) == 10):
        name += 1
        
    
    
print(medical_atk_stats)
